import streamlit as st
import sqlite3
from datetime import datetime

def get_connection():
    return sqlite3.connect('hoteldb2025.db')


def fetch_query(query, params=()):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    results = cursor.fetchall()
    columns = [desc[0] for desc in cursor.description]
    conn.close()
    return results, columns

def execute_query(query, params=()):
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    conn.close()


st.title("Gestion de l'Hôtel")

# Question 1. tableau des reservation
st.header("Tableau des Réservations")
reservations, res_columns = fetch_query('''
    SELECT R.id, R.date_debut, R.date_fin, C.nom_complet, H.ville
    FROM Reservation R
    JOIN Client C ON R.client_id = C.id
    JOIN Reservation_Chambre RC ON R.id = RC.reservation_id
    JOIN Chambre CH ON RC.chambre_id = CH.id
    JOIN Hotel H ON CH.hotel_id = H.id
''')
st.table([dict(zip(res_columns, row)) for row in reservations])

## Question 2. tableau des client
st.header("Tableau des Clients")
clients, client_columns = fetch_query('SELECT * FROM Client')
st.table([dict(zip(client_columns, row)) for row in clients])


# Question 3. consultaion des listes de chambre.
st.header("Les Chambres Disponibles")
date_debut = st.date_input("Date de début")
date_fin = st.date_input("Date de fin")
if date_debut and date_fin:
    if date_debut >= date_fin:
        st.error("La date de début doit être inférieure à la date de fin.")
    else:
        chambres, chambre_columns = fetch_query('''
            SELECT C.* FROM Chambre C
            WHERE C.id NOT IN (
                SELECT RC.chambre_id
                FROM Reservation_Chambre RC
                JOIN Reservation R ON RC.reservation_id = R.id
                WHERE R.date_debut < ? AND R.date_fin > ?
            )
        ''', (date_fin, date_debut))
        st.table([dict(zip(chambre_columns, row)) for row in chambres])
        


# Question 4. l'Ajouter de client
st.header("Ajouter un Client")
with st.form("add_client_form"):
    nom_complet = st.text_input("Nom complet")
    adresse = st.text_input("Adresse")
    ville = st.text_input("Ville")
    code_postal = st.number_input("Code postal", min_value=0, step=1)
    email = st.text_input("Email")
    telephone = st.text_input("Téléphone")
    submit_client = st.form_submit_button("Ajouter Client")

    if submit_client:
        if not all([nom_complet, adresse, ville, code_postal, email, telephone]):
            st.error("Tous les champs doivent être remplis.")
        else:
            # donner un nouvel ID pour le client
            max_client_id = fetch_query('SELECT MAX(id) FROM Client')[0][0][0] or 0
            new_client_id = max_client_id + 1
            # Insértion de nouveau client
            execute_query('''
                INSERT INTO Client (id, nom_complet, adresse, ville, code_postal, email, telephone)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (new_client_id, nom_complet, adresse, ville, code_postal, email, telephone))
            st.success(f"Client {nom_complet} ajouté avec succès !")
            
            
            
# Question 5. l'Ajouter de réservation
st.header("Ajouter une Réservation")
with st.form("add_reservation_form"):
    client_id = st.selectbox("Client", [c[0] for c in fetch_query('SELECT id FROM Client')[0]])
    chambre_id = st.selectbox("Chambre", [c[0] for c in fetch_query('SELECT id FROM Chambre')[0]])
    new_date_debut = st.date_input("Date de début (nouvelle réservation)")
    new_date_fin = st.date_input("Date de fin (nouvelle réservation)")
    submit = st.form_submit_button("Ajouter")

    if submit:
        if new_date_debut >= new_date_fin:
            st.error("La date de début doit être inférieure à la date de fin.")
        else:
            # Vérifier si la chambre est disponible
            conflicts, _ = fetch_query('''
                SELECT * FROM Reservation R
                JOIN Reservation_Chambre RC ON R.id = RC.reservation_id
                WHERE RC.chambre_id = ?
                AND R.date_debut < ? AND R.date_fin > ?
            ''', (chambre_id, new_date_fin, new_date_debut))
            
            if conflicts:
                st.error("La chambre est déjà réservée pour cette période.")
            else:
                # Insérer la réservation
                max_res_id = fetch_query('SELECT MAX(id) FROM Reservation')[0][0][0] or 0
                new_res_id = max_res_id + 1
                execute_query('INSERT INTO Reservation (id, date_debut, date_fin, client_id) VALUES (?, ?, ?, ?)',
                             (new_res_id, new_date_debut, new_date_fin, client_id))
                execute_query('INSERT INTO Reservation_Chambre (reservation_id, chambre_id) VALUES (?, ?)',
                             (new_res_id, chambre_id))
                st.success("Réservation ajoutée avec succès !")
                

