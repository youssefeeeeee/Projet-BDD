--  Afficher la liste des réservations avec le nom du client et la ville de l’hôtel réservé
SELECT R.id, R.date_debut, R.date_fin, C.nom_complet, H.ville
FROM Reservation AS R
JOIN Client C ON R.client_id = C.id
JOIN Reservation_Chambre RC ON R.id = RC.reservation_id
JOIN Chambre CH ON RC.chambre_id = CH.id
JOIN Hotel H ON CH.hotel_id = H.id;

-- Afficher les clients qui habitent à Paris
SELECT * FROM Client WHERE ville = 'Paris';

-- Calculer le nombre de réservations faites par chaque client
SELECT C.nom_complet, COUNT(R.id) AS nb_reservations
FROM Client C
LEFT JOIN Reservation R ON C.id = R.client_id
GROUP BY C.nom_complet;

-- Donner le nombre de chambres pour chaque type de chambre
SELECT TC.type, COUNT(CH.id) AS nb_chambres
FROM TypeChambre TC
JOIN Chambre CH ON TC.id = CH.type_id
GROUP BY TC.type;

-- Afficher la liste des chambres qui ne sont pas réservées pour une période donnée (entre deux dates saisies par l’utilisateur)
SELECT * FROM Chambre
WHERE id NOT IN (
    SELECT chambre_id
    FROM Reservation_Chambre RC
    JOIN Reservation R ON RC.reservation_id = R.id
    WHERE R.date_debut < @date_fin AND R.date_fin > @date_debut
);
